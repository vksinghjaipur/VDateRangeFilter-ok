<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Student;
use Illuminate\Http\Request;
use DB;
// use DataTables;

class StudentController extends Controller
{
    public function index()
    {
        return view('students');
    }

    




    public function webIndex()
    {
        return view('vikash.index');
    }


    public function fetch_data(Request $request)
    {
     if($request->ajax())
     {
      if($request->from_date != '' && $request->to_date != '')
      {
       //$data = DB::table('students')
        $data=Student::whereBetween('created_at',array($request->from_date, $request->to_date))

         //whereDate('created_at', array($request->from_date, $request->to_date))
         //whereBetween('created_at', array($request->from_date.'00:00:00', $request->to_date.'23:59:59'))
         ->get();
      }
      else
      {
       $data = DB::table('students')->orderBy('created_at', 'desc')->get();
      }
      echo json_encode($data);
     }
    }
}